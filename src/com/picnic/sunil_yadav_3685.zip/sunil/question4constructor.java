package com.picnic.sunil;

public class question4constructor {
	
	int id;  
    String name;  
      
    question4constructor (int i,String n){  
    id = i;  
    name = n;  
    }  
      
    void display(){System.out.println(id+" "+name);}  
   
    public static void main(String args[]){  
      
    	question4constructor s1 = new question4constructor(111,"Sunil");  
    	question4constructor s2 = new question4constructor(222,"Anil");  
   
    s1.display();  
    s2.display();  
   }  
}  