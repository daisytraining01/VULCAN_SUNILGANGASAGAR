package com.picnic.sunil;

public class question4inheritance {
	
	float salary=40000;  
	}  
	class Programmer extends question4inheritance{  
	 int bonus=10000;  
	 public static void main(String args[]){  
	   Programmer p=new Programmer();  
	   System.out.println(" My salary is:"+p.salary);  
	   System.out.println("My Bonus is :"+p.bonus);  
	}  
	}

