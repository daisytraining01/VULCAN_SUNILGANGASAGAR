package com.picnic.sunil;

public class question5 {
	
	public static void main(String[] args) {
		String str = "REST ASSURED";

		//System.out.println("String after Removing 'S' = "+str.replace("S", "T"));
		
		System.out.println("String after Removing First 'ST' = "+str.replaceFirst("ST", ""));

	//	System.out.println("String after replacing all small letters = "+str.replaceAll("([a-z])", ""));
	}

}

	
	