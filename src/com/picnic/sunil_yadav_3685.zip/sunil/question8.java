package com.picnic.sunil;

public class question8 {
	
	static int add(int a,int b){return a+b;}  
	static int add(int a,int b,int c){return a+b+c;}  
	}  
	class TestOverloading1{  
	public static void main(String[] args){  
	System.out.println(question8.add(11,11));  
	System.out.println(question8.add(11,11,11));  
	}}  

	